# rebar plugin

This plugin adds completions for the [rebar](https://www.rebar3.org/) Erlang build tool.

To use it, add `rebar` to the plugins array in your zshrc file:

```zsh
plugins=(... rebar)
```
